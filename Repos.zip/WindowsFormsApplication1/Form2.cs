﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public Form2(string text)
        {
            InitializeComponent();
            this.text = text;
        }
        DataTable dt = new DataTable();
        string text = "";
        private void Form2_Load(object sender, EventArgs e)
        {
            dt.Columns.Add("txtBox");
            dt.Rows.Add(text);
            crystal cr = new crystal();
            cr.SetDataSource(dt);
            crystalReportViewer1.ReportSource = cr;
        }
    }
}
